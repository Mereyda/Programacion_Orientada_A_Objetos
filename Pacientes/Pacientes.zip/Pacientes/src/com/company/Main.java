package com.company;

import java.util.Date;

public class Main {

    public static void main(String[] args) throws FechaException {
        try {
            Paciente paciente=new Paciente("Juan","Perez","12345",new Date(2021,9,6));
            paciente.darAlta(new Date(2022, 9,  15));

        } catch (FechaException e){
            System.out.println( e.getMessage());

        }



    }
}
