public interface StrategyTransporte {
    public double calculoTiempo(Punto a, Punto b);

}
