public class Bicicleta implements StrategyTransporte{

    @Override
    public double calculoTiempo(Punto a, Punto b) {
        return a.distancia(b)/0.050366 * 1.5;
    }
}
