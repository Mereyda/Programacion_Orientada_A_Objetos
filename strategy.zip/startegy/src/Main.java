public class Main {
    public static void main(String[] args) {
        Punto a = new Punto(389,458);
        Punto b= new Punto(780,599);
        Mapa westeros= new Mapa();
        westeros.setEstrategiaTransporte(new Automovil());
        System.out.println(westeros.calculaTiempo(a,b));
        westeros.setEstrategiaTransporte(new Bicicleta());
        System.out.println(westeros.calculaTiempo(a,b));
        westeros.setEstrategiaTransporte(new Caminando());
        System.out.println(westeros.calculaTiempo(a,b));
    }
}
