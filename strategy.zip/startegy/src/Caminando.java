public class Caminando implements StrategyTransporte{

    @Override
    public double calculoTiempo(Punto a, Punto b) {
        return a.distancia(b)/0.20366*13;
    }
}
