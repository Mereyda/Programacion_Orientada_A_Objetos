public class Mapa {
    private StrategyTransporte estrategiaTransporte;

    public StrategyTransporte getEstrategiaTransporte() {
        return estrategiaTransporte;
    }

    public void setEstrategiaTransporte(StrategyTransporte estrategiaTransporte) {
        this.estrategiaTransporte = estrategiaTransporte;
    }

    public double calculaTiempo(Punto a, Punto b){
        return estrategiaTransporte.calculoTiempo(a,b);

    }
}
