public class Automovil implements StrategyTransporte{

    @Override
    public double calculoTiempo(Punto a, Punto b) {
        return a.distancia(b)/ 0.40366 * 4;
    }
}
