package PatronComposite;

public  abstract class Figura {
    public abstract double calcularArea();
}
