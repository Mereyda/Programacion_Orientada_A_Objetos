public class CargaSimple extends Carga{

    private double peso;
    private Boolean refrigerado;

    public CargaSimple(String nombre, String descripcion, double peso, Boolean refrigerado) {
        super(nombre, descripcion);
        this.peso = peso;
        this.refrigerado = refrigerado;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public Boolean getRefrigerado() {
        return refrigerado;
    }

    public void setRefrigerado(Boolean refrigerado) {
        this.refrigerado = refrigerado;
    }

    @Override
    public double calcularPeso() {
        if (refrigerado)
            return peso * 1.1;
        return peso;
    }
}
