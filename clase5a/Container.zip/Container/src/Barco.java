import java.util.ArrayList;
import java.util.List;

public class Barco {
    private List<Carga> ListaContenedores;
    private String name;

    public Barco(String name) {
        this.name = name;
        this.ListaContenedores = new ArrayList<Carga>();
    }
    public void agregarCarga(Carga c){
        this.ListaContenedores.add(c);
    }

    public void informe(){
        for (Carga c: ListaContenedores) {
            System.out.println("El barco: "+c.getNombre()+", Con el peso: "+c.calcularPeso());
        }
    }

}
