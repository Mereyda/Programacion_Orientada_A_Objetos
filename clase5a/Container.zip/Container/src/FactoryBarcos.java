import java.util.Scanner;

public class FactoryBarcos {
    private static FactoryBarcos Instance;
    private void FactoryBarcos(){};

    public static FactoryBarcos getInstance(){
        if (Instance == null)
            Instance = new FactoryBarcos();
        return Instance;
    }

    public Carga generar(String s){
        Scanner f = new Scanner(System.in);
        switch (s){
            case "cargasimple":
                System.out.println("Ingrese el nombre del contenedor simple: ");
                String nombre = f.nextLine();
                System.out.println("Ingrese la descripcion del contenedor simple: ");
                String descripcion = f.nextLine();
                System.out.println("Ingrese el peso del contenedor simple: ");
                double peso = f.nextDouble();
                System.out.println("Ingrese si es refrigerado | True | False: ");
                Boolean ref = f.nextBoolean();
                return new CargaSimple(nombre,descripcion,peso,ref);
            case "cargacontenedor":
                System.out.println("Ingrese el nombre del contenedor simple: ");
                String nombree = f.nextLine();
                System.out.println("Ingrese la descripcion del contenedor simple: ");
                String descripcionn = f.nextLine();
                System.out.println("Ingrese el peso propio: ");
                double pesopro = f.nextDouble();
                return new CargaContenedor(nombree,descripcionn,pesopro);
            default:
                return null;
        }
    }
}
