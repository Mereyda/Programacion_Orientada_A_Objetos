public class Main {
    public static void main(String[] args) {
        FactoryBarcos f = FactoryBarcos.getInstance();
        CargaSimple cs1 = (CargaSimple) f.generar("cargasimple");
        CargaSimple cs2 = (CargaSimple) f.generar("cargasimple");

        CargaContenedor cc1 = (CargaContenedor) f.generar("cargacontenedor");

        cc1.agregar(cs1);
        cc1.agregar(cs2);

        Barco b =  new Barco("Piratas del caribe");
        b.agregarCarga(cs1);
        b.agregarCarga(cs2);
        b.agregarCarga(cc1);

        b.informe();
    }
}
