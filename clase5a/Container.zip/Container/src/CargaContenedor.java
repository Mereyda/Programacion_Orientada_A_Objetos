import java.security.PrivateKey;
import java.util.ArrayList;
import java.util.List;

public class CargaContenedor extends Carga{

    private List<CargaSimple> ListaCargas;
    private double pesoPropio;

    public CargaContenedor(String nombre, String descripcion, double pesoPropio) {
        super(nombre, descripcion);
        this.pesoPropio = pesoPropio;
        this.ListaCargas = new ArrayList<CargaSimple>();
    }

    public double getPesoPropio() {
        return pesoPropio;
    }

    public void setPesoPropio(double pesoPropio) {
        this.pesoPropio = pesoPropio;
    }

    public void agregar(CargaSimple cs){
        this.ListaCargas.add(cs);
    }

    @Override
    public double calcularPeso() {
        double suma = pesoPropio;
        for (CargaSimple cs: ListaCargas) {
            suma += cs.calcularPeso();
        }
        return suma;
    }
}
