public class Main {
    public static void main(String[] args) {


        try {
            FactoryHabilidad f = FactoryHabilidad.getInstance();
            HabilidadSimple hs1 = (HabilidadSimple) f.Generar("habilidadsimple");
            HabilidadSimple hs2 = (HabilidadSimple) f.Generar("habilidadsimple");

            HabilidadCombinada hc = (HabilidadCombinada) f.Generar("habilidadcombinada");

            hc.agregar(hs1);
            hc.agregar(hs2);

            Personaje p = new Personaje();

            p.agregar(hs1);
            p.agregar(hs2);
            p.agregar(hc);

            p.informe();

            f.Generar("Aca va a saltar la exception");
        }catch (Exception e){
            System.out.println(e);
        }
    }
}