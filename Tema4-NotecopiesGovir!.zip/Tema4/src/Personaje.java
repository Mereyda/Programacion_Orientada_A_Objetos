import java.util.ArrayList;
import java.util.List;

public class Personaje {

    private List<Habilidad> ListaHabilidad;

    public Personaje() {
        ListaHabilidad = new ArrayList<Habilidad>();
    }

    public void agregar(Habilidad h){
        this.ListaHabilidad.add(h);
    }

    public void informe(){
        for(Habilidad h: ListaHabilidad){
            System.out.println("La habilidad: "+ h.getNombre()+ ", con el puntaje: "+h.calcularPuntaje());
        }
    }
}
