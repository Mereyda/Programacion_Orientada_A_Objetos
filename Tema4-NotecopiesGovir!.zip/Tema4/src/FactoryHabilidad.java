import java.util.Scanner;

public class FactoryHabilidad {
    private static FactoryHabilidad instance;
    private FactoryHabilidad(){}

    public static FactoryHabilidad getInstance(){
        if (instance == null)
            instance = new FactoryHabilidad();
        return instance;
    }

    public Habilidad Generar(String s) throws Exception {
        Scanner scanner = new Scanner(System.in);
        switch (s){
            case "habilidadsimple":
                System.out.println("Ingrese un nombre para la habilidad");
                String nombre = scanner.nextLine();
                System.out.println("Ingrese una descripcion para la habilidad");
                String desc = scanner.nextLine();
                System.out.println("Ingrese un puntaje para la habilidad");
                Double puntaje = scanner.nextDouble();
                return new HabilidadSimple(nombre,desc,puntaje);
            case "habilidadcombinada":
                System.out.println("Ingrese un nombre para la habilidad");
                String nombree = scanner.nextLine();
                System.out.println("Ingrese una descripcion para la habilidad");
                String descc = scanner.nextLine();
                System.out.println("Ingrese un multiplicador para la habilidad");
                int mul = scanner.nextInt();
                return new HabilidadCombinada(nombree,descc,mul);
            default:
                throw new Exception("No existe este tipo de habilidad");
        }
    }
}
