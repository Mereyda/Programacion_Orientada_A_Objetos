import java.util.ArrayList;
import java.util.List;

public class HabilidadCombinada extends Habilidad{

    private int factorMultiplicador;
    private List<HabilidadSimple> ListaHabilidadesSimples;

    public HabilidadCombinada(String nombre, String descripcion, int factorMultiplicador) {
        super(nombre, descripcion);
        this.factorMultiplicador = factorMultiplicador;
        this.ListaHabilidadesSimples = new ArrayList<HabilidadSimple>();
    }

    public int getFactorMultiplicador() {
        return factorMultiplicador;
    }

    public void setFactorMultiplicador(int factorMultiplicador) {
        this.factorMultiplicador = factorMultiplicador;
    }

    public void agregar(HabilidadSimple hs){
        this.ListaHabilidadesSimples.add(hs);
    }

    @Override
    public double calcularPuntaje() {
        double suma = 0.0;
        for(HabilidadSimple hs: ListaHabilidadesSimples){
            suma += hs.calcularPuntaje();
        }
        return suma * this.getFactorMultiplicador();
    }
}
